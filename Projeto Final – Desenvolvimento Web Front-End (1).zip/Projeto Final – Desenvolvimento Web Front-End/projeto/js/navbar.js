class CustomNavbar extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
            <nav class="bg-indigo-700 text-white p-4">
                <div class="container mx-auto flex justify-between">
                    <h1 class="font-bold text-xl">EduTrack</h1>
                    <ul class="flex gap-6">
                        <li><a href="index.html" class="hover:underline">Início</a></li>
                        <li><a href="cadastro.html" class="hover:underline">Cadastro</a></li>
                        <li><a href="lista.html" class="hover:underline">Alunos</a></li>
                        <li><a href="relatorios.html" class="hover:underline">Relatórios</a></li>
                    </ul>
                </div>
            </nav>
        `;
    }
}

customElements.define('custom-navbar', CustomNavbar);
