const form = document.getElementById("form-aluno");
const tabela = document.getElementById("tabela-alunos");

let alunos = [];

form.addEventListener("submit", function (event) {
    event.preventDefault();

    const nome = document.getElementById("nome").value;
    const idade = document.getElementById("idade").value;
    const curso = document.getElementById("curso").value;

    // Validação básica
    if (nome.trim() === "" || idade === "" || curso === "") {
        alert("Preencha todos os campos!");
        return;
    }

    const aluno = { nome, idade, curso };
    alunos.push(aluno);

    atualizarTabela();
    form.reset();
});

// Atualiza a tabela exibindo alunos cadastrados
function atualizarTabela() {
    tabela.innerHTML = "";

    alunos.forEach((aluno, index) => {
        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td>${aluno.nome}</td>
            <td>${aluno.idade}</td>
            <td>${aluno.curso}</td>
            <td>
                <button class="delete" onclick="removerAluno(${index})">Excluir</button>
            </td>
        `;

        tabela.appendChild(tr);
    });
}

function removerAluno(i) {
    alunos.splice(i, 1);
    atualizarTabela();
}
