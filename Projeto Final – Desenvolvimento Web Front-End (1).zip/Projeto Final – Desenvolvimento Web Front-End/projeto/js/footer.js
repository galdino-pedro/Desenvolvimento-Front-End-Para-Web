class CustomFooter extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
            <footer class="bg-gray-800 text-gray-300 py-6 mt-12">
                <div class="container mx-auto text-center">
                    <p>© 2024 EduTrack - Sistema de Gerenciamento Escolar</p>
                </div>
            </footer>
        `;
    }
}

customElements.define('custom-footer', CustomFooter);
